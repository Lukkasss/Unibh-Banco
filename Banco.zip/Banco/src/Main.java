import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Created by IntelliJ IDEA.
 * User: Lucas Vilela
 * Date: 20/10/2018
 * Time: 16:28
 * To change this template use File | Settings | File and Code Templates.
 */
public class Main {
    public static void main(String[] args) {

        Integer optionId = null;

        Scanner input = new Scanner(System.in);
        HashMap<String, Cliente> Clientes = new HashMap<>();
        HashMap<String, ArrayList<Conta>> Contas = new HashMap<>();
        ArrayList<Conta> arr = new ArrayList<>();

        do {
            System.out.println("Bem vindo ao sistema bancário");
            System.out.println("Menu");
            System.out.println("1 - Cadastrar Cliente");
            System.out.println("2 - Cadastrar Conta");
            System.out.println("3 - Consultar Saldo");
            System.out.println("4 - Depositar");
            System.out.println("5 - Sacar");
            System.out.println("6 - Imprimir Dados do Cliente");

            optionId = Integer.parseInt(input.nextLine());

            switch (optionId) {
                case 1: {
                    String cpf, nome, logradouro, cidade, uf;
                    int numero, cep;

                    System.out.print("Digite o CPF do cliente: ");
                    cpf = input.nextLine();
                    System.out.println("Digite o NOME do cliente: ");
                    nome = input.nextLine();
                    System.out.println("Digite o LOGRADOURO do cliente: ");
                    logradouro = input.nextLine();
                    System.out.println("Digite o NÚMERO do LOGRADOURO do cliente: ");
                    numero = Integer.parseInt(input.nextLine());
                    System.out.println("Digite o CEP do cliente: ");
                    cep = Integer.parseInt(input.nextLine());
                    System.out.println("Digite a CIDADE do cliente: ");
                    cidade = input.nextLine();
                    System.out.println("Digite o UF do cliente: ");
                    uf = input.nextLine();
                    Cliente c = new Cliente(cpf, nome, new Endereco(logradouro, cidade, uf, numero, cep));
                    Clientes.put(cpf, c);
                }
                    break;

                case 2: {
                    String cpf, agencia, numero;
                    double saldo;
                    boolean tipo;
                    System.out.print("Para qual cliente você gostaria de abrir a conta? Digite o CPF do cliente: ");
                    cpf = input.nextLine();
                    System.out.print("Digite o número da agência: ");
                    agencia = input.nextLine();
                    System.out.print("Digite o número da conta: ");
                    numero = input.nextLine();
                    System.out.print("Digite o saldo da conta: ");
                    saldo = Double.parseDouble(input.nextLine());
                    System.out.print("Digite o tipo da conta(TRUE = CORRENTE, FALSE = POUPANÇA):  ");
                    tipo = Boolean.parseBoolean(input.nextLine());
                    if(tipo){
                        double limite;
                        System.out.print("Digite o limite disponível da conta: ");
                        limite = Double.parseDouble(input.nextLine());

                        Conta c = new Corrente(limite, agencia, numero, saldo, Clientes.get(cpf));
                        arr.add(c);
                        Contas.put(cpf, arr);

                    } else {
                        Conta c = new Poupanca(agencia, numero, saldo, Clientes.get(cpf));
                        arr.add(c);
                        Contas.put(cpf, arr);
                    }

                }
                break;

                case 3: {
                    String numero;
                    System.out.print("Digite o número da conta para consultar o saldo: ");
                    numero = input.nextLine();
                    for(ArrayList<Conta> data : Contas.values()){
                        for(int i = 0; i < data.size(); i++){
                         if(data.get(i).getNumero().equals(numero)){
                             System.out.println(data.get(i).consultarSaldo());
                         }
                        }
                    }
                }
                break;

                case 4: {
                    String numero;
                    double valor;
                    System.out.print("Digite o número da conta: ");
                    numero = input.nextLine();
                    System.out.print("Digite o valor para depósito: ");
                    valor = Double.parseDouble(input.nextLine());

                    for(ArrayList<Conta> data : Contas.values()){
                        for(int i = 0; i < data.size(); i++){
                            if(data.get(i).getNumero().equals(numero)){
                                data.get(i).depositar(valor);
                            }
                        }
                    }
                }
                break;

                case 5: {
                    String numero;
                    double valor;
                    System.out.print("Digite o número da conta: ");
                    numero = input.nextLine();
                    System.out.print("Digite o valor do saque: ");
                    valor = Double.parseDouble(input.nextLine());

                    for(ArrayList<Conta> data : Contas.values()){
                        for(int i = 0; i < data.size(); i++){
                            if(data.get(i).getNumero().equals(numero)){
                                data.get(i).sacar(valor);
                            }
                        }
                    }
                }
                break;

                case 6: {
                    String cpf;
                    ArrayList<String> contasCpf = new ArrayList<>();
                    System.out.print("Digite o cpf da pessoa: ");
                    cpf = input.nextLine();

                    System.out.print(Clientes.get(cpf).imprimirDados());
                    System.out.println("Contas referentes a esse cliente: ");

                    for(ArrayList<Conta> data : Contas.values()){
                        for(int i = 0; i < data.size(); i++){
                            if(data.get(i).getCliente().getCpf().equals(cpf)){
                                if(!contasCpf.contains(data.get(i).getNumero()))
                                    contasCpf.add(data.get(i).getNumero());
                            }
                        }
                    }
                    System.out.println(contasCpf);
                }
                break;

            }
        }
        while(optionId != 0);



    }
}
